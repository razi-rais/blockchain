module.exports = {
  networks: {
    development: {
      host: "localhost",
      port: 8545,
      network_id: "*" // Match any network id
    },
    pre_production: {
      host: "<<POINT TO PRE-PRODUCTION>>",
      port: 8545,
      network_id: "*" // Match any network id
    }
  }
};
